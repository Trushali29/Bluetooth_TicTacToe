package com.example.myapplicationgame;

public class ClientSide {
}
